﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PcHut.Models;

namespace PcHut.Repository
{
    public class BrandRepository : Repository<brand>
    {
    }
}