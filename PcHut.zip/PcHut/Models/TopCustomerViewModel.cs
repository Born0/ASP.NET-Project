﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PcHut.Models
{
    public class TopCustomerViewModel
    {
        public int User_Id { get; set; }
        public double? Column1 { get; set; }
    }
}