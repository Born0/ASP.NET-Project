﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PcHut.Models
{
    public class VendorMaxBrandViewModel
    {
        public int Vendor_id { get; set; }
        public int NumberOfBrand { get; set; }
    }
}