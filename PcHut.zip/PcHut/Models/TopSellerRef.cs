﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PcHut.Models
{
    public class TopSellerRef
    {
        public int Seller_Refference { get; set; }
        public double ToatalSumAmount { get; set; }
    }
}